<template>
  <div>TODO - реализовать страницу регистрации пользователя</div>
</template>

<script setup lang="ts"></script>
