<template>
  <!-- TODO - реализовать переключатель темы -->
  <div>TODO - реализовать переключатель темы</div>
</template>

<script setup lang="ts"></script>
