<template>
  <button>
    <router-link to="/auth/login" style="text-decoration: none">
      <span class="hidden-md-and-down">Личный кабинет</span>
    </router-link>
  </button>
</template>

<script setup lang="ts"></script>
