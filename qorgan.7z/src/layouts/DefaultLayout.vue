<template>
  <main>
    <!-- <BaseHeader /> -->
    <BaseContent />
    <!-- <BaseFooter /> -->
  </main>
</template>

<script setup lang="ts">
import BaseHeader from "@/components/common/BaseHeader.vue";
import BaseContent from "@/components/common/BaseContent.vue";
import BaseFooter from "@/components/common/BaseFooter.vue";
</script>
