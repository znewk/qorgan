<template>
  <main>
    <LoginPage/>
  </main>
</template>

<script setup lang="ts">
import BaseFooter from "@/components/common/BaseFooter.vue";
import LoginPage from "@/components/auth/LoginPage.vue";
</script>